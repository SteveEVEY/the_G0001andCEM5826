1.进入Samples\LibSamples\USART\USART_Interrupt\MDK-ARM目录；
2.打开USART_Interrupt.uvprojx文件。